import { Flex, Text, Stack} from '@chakra-ui/core'


export default function Meintenance() {

  return (  
      <Flex w="100%" justify="center" mt={10}>
        <Stack align="center">
            <Text>Down For Maintenance</Text>
        </Stack>
      </Flex>
  )
}
