import Nft from '../../components/Nft'

export default function VaultPage(): JSX.Element {
  return <Nft />
}
