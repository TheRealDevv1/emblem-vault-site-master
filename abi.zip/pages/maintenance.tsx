import Maintenance from '../components/Maintenance'

export default function MaintenancePage(): JSX.Element {
  return <Maintenance />
}
