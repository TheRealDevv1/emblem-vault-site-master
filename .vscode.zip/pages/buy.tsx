import Swap from '../components/Swap'

export default function Buy(): JSX.Element {
  return <Swap buy={true} />
}
