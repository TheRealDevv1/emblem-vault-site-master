import Swap from '../components/Swap'

export default function Sell(): JSX.Element {
  return <Swap buy={false} />
}
