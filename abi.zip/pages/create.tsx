import Create from '../components/Create'

export default function CreateVault(): JSX.Element {
  return <Create />
}
