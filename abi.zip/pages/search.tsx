import Search from '../components/Search'

export default function SearchPage(): JSX.Element {
  return <Search />
}
