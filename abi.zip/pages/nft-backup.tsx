import Nft from '../components/Nft'

export default function NftPage(): JSX.Element {
  return <Nft />
}
