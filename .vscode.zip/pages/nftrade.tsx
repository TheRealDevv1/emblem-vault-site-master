import Nftrade from '../components/Nftrade'

export default function SearchPage(): JSX.Element {
  return <Nftrade />
}
